import { createContext, useEffect } from "react";
import { food_list } from "../assets/food del assets/frontend_assets/assets";
import { useState } from "react";
import axios from "axios";

export const storeContext = createContext(null);

const storeContextProvider = (props) => {
  const [cartItems, setCartItems] = useState({});
  const url = "http://localhost:4000";
  const [token, setToken] = useState("");
  // const [food_list, setFood_list] = useState([]);

  const addToCart = (itemId) => {
    if (!cartItems[itemId]) {
      // Corrected the typo here
      setCartItems((prev) => ({ ...prev, [itemId]: 1 }));
    } else {
      setCartItems((prev) => ({ ...prev, [itemId]: prev[itemId] + 1 }));
    }
  };

  const RemoveFromCart = (itemid) => {
    setCartItems((prev) => ({ ...prev, [itemid]: prev[itemid] - 1 }));
  };

  const getTotalCartAmont = () => {
    let totalAmount = 0;
    for (let item in cartItems) {
      if (cartItems[item] > 0) {
      }
      let itemInfo = food_list.find((x) => x._id === item);
      totalAmount += itemInfo.price * cartItems[item];
    }
    return totalAmount;
  };

  const feachFoodList = async () => {
    try {
      const response = await axios.get(url + "/api/v1/food/list");
      setFood_list(response.data.data);
    } catch (error) {
      console.error("you got error:", error);
    }
  };

  useEffect(() => {
    try {
      async function loadData() {
        await feachFoodList();
        if (localStorage.getItem("token")) {
          setToken(localStorage.getItem("token"));
        }
      }
      loadData();
    } catch (error) {
      console.log(error);
    }
  }, []);

  const contextValue = {
    food_list,
    cartItems,
    setCartItems,
    addToCart,
    RemoveFromCart,
    getTotalCartAmont,
    url,
    setToken,
    token,
  };
  return (
    <storeContext.Provider value={contextValue}>
      {props.children}
    </storeContext.Provider>
  );
};

export default storeContextProvider;
