import React, { useContext } from "react";
import "./PlaceOrder.css";
import { storeContext } from "../../context/Context";


const PlaceOrder = () => {
  const { getTotalCartAmont } = useContext(storeContext);
  return (
    <form action="" className="place-order">
      <div className="PlaceOrder-left">
        <p className="title">Delivey info</p>
        <div className="muli-fields">
          <input type="text" name="" id="" placeholder="First name" />
          <input type="text" name="" id="" placeholder="Last name" />
        </div>
        <input type="email" name="" id="" placeholder="Email Address" />
        <input type="text" name="" id="" placeholder="street" />
        <div className="muli-fields">
          <input type="text" name="" id="" placeholder="city name" />
          <input type="text" name="" id="" placeholder="state name" />
        </div>
        <div className="muli-fields">
          <input type="text" name="" id="" placeholder="Zip code" />
          <input type="text" name="" id="" placeholder="country" />
        </div>
        <input type="text" placeholder="phone" />
      </div>
      <div className="placeorder-right">
      <div className="cart-bottom">
        <div className="cart-total">
          <h2>Cart total</h2>
          <div >
            <div className="cart-total-details">
              <p>Subtotal</p>
              <p>${getTotalCartAmont()}</p>
            </div>
            <hr />
            <div className="cart-total-details">
              <p>Shipping fee</p>
              <p>${getTotalCartAmont()===0?0:2}</p>
            </div>
            <hr />
            <div className="cart-total-details">
              <b>Total</b>
              <b>${getTotalCartAmont()===0?0:getTotalCartAmont() + 2}</b>
            </div>
            <button onClick={() =>navigate("/order")}>Proceed to pay</button>
          </div>
          <div className="cart-promocode">
            <div>
              <p>If You have a promocode</p>
              <div className="cart-promocode-input">
                <input type="text" placeholder="Enter promocode" />
                <button>Apply</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      </div>
    </form>
  );
};

export default PlaceOrder;
